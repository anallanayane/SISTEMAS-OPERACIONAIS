﻿#include <cstdio>       //printf
#include <cstring>      //memset
#include <cstdlib>      //exit
#include <netinet/in.h> //htons
#include <arpa/inet.h>  //inet_addr
#include <sys/socket.h> //socket
#include <unistd.h>     //close
#include <iostream>
#include <unistd.h>
#include "BlackGPIO/BlackGPIO.h"
//Includes da medição analógica
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

//Medição analógica
#define PATH_ADC "/sys/bus/iio/devices/iio:device0/in_voltage"

#define MAXMSG 1024
#define MAXNAME 100
#define PORTNUM 4325

class Mensagem {
    public:
        //char msg[MAXMSG];
        int velocidade;
        char nome[MAXNAME];
        int acao;
        int trem;
        Mensagem();
};
 
Mensagem::Mensagem()
{
    acao = 1;
}

// Função de leitura do potenciometro
int readAnalog(int number){
   
    stringstream ss;
      
     ss << PATH_ADC << number << "_raw";
      
     fstream fs;
      
     fs.open(ss.str().c_str(), fstream::in);
       
       fs >> number;
       fs.close();
       
    return number;
}
 
int main(int argc, char *argv[])
{
    struct sockaddr_in endereco;
    int socketId;
 
    Mensagem mensagem;

    mensagem.velocidade = readAnalog(1);
   // strcpy(mensagem.msg,valor);
   // strcpy(mensagem.velocidade, valor);
    strcpy(mensagem.nome,"MacGyver");

    int bytesenviados;
 
    /*
     * Configurações do endereço
    */
    memset(&endereco, 0, sizeof(endereco));
    endereco.sin_family = AF_INET;
    endereco.sin_port = htons(PORTNUM);
    endereco.sin_addr.s_addr = inet_addr("192.168.7.1");
 
    /*
     * Criando o Socket
     *
     * PARAM1: AF_INET ou AF_INET6 (IPV4 ou IPV6)
     * PARAM2: SOCK_STREAM ou SOCK_DGRAM
     * PARAM3: protocolo (IP, UDP, TCP, etc). Valor 0 escolhe automaticamente
    */
    socketId = socket(AF_INET, SOCK_STREAM, 0);
 
    //Verificar erros
    if (socketId == -1)
    {
        printf("Falha ao executar socket()\n");
        exit(EXIT_FAILURE);
    }
 
    //Conectando o socket cliente ao socket servidor
    if ( connect (socketId, (struct sockaddr *)&endereco, sizeof(struct sockaddr)) == -1 )
    {
        printf("Falha ao executar connect()\n");
        exit(EXIT_FAILURE);
    }

    printf ("Cliente conectado ao servidor\n");
    cout << "Insira 1 para ligar/desligar todos os trens," << endl;
    cout << "Insira 2 para fechar a conexão com o servidor" << endl;
    cout << "Insira 3 para mudar a velocidade de um trem" << endl;
    cout << "Insira 4 para ligar/desligar um trem específico" << endl;
    
    bool rodando = true;
    while(rodando){
        std::cin >> mensagem.acao;
        if(mensagem.acao == 1) {
        
            printf("Cliente enviou a seguinte msg (%d bytes) para o servidor: ligar/desligar todos os trens");
        }

        else if(mensagem.acao == 2){
            close(socketId);
            printf("Conexão com o servidor encerrada.");
        }
        else if(mensagem.acao == 3){

            cout << "Escolha o trem que deseja mudar a velocidade: " << endl;
            cin >> mensagem.trem;
            mensagem.velocidade = readAnalog(1);
            cout << "\n";
            printf("Cliente enviou a seguinte msg (%d bytes) para o servidor: Mudar a velocidade do trem %d para %d  \n",bytesenviados, mensagem.trem, mensagem.velocidade);
        }
        else if(mensagem.acao == 4){
            cout << "Escolha o trem que deseja ligar/desligar: " << endl;
            cin >> mensagem.trem;
            cout << "\n";
            printf("Cliente enviou a seguinte msg (%d bytes) para o servidor: Desligar o trem %d,  \n",bytesenviados, mensagem.trem);
        }

        bytesenviados = send(socketId,&mensagem,sizeof(mensagem),0);
            

            if (bytesenviados == -1 && mensagem.acao != 2)
            {
                printf("Falha ao executar send()");
                exit(EXIT_FAILURE);
            }
    }

    close(socketId);
 
    return 0;
}