#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "trem.h"
#include "Semaforo.h"
#include <QMainWindow>
#include <QCloseEvent>
#include <QString>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <cstdio>       //printf
#include <cstring>      //memset
#include <cstdlib>      //exit
#include <netinet/in.h> //htons
#include <thread>
#include <iostream>
#include <vector>

using namespace std;

#define MAXNAME 100
#define PORTNUM 4327

namespace Ui {
class MainWindow;
}

class Mensagem {
    public:
        int velocidade;
        char nome[MAXNAME];
        int acao;
        int trem;
        Mensagem();
};

/*class Server
{
public:
    Server();
    int socketId;
}; */

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void closeEvent();
    void changeVelocidade(int id, int velocidade);
    void server();
    static void socketHandler(MainWindow *window, int conexaoClienteID, Mensagem mensagem);
   // void socketHandler(int socketDescriptor,Mensagem mensagem);
    //int socketId;

public slots:
    void updateInterface(int, int, int, bool a);
    void infoSemaforo();

private:
    Ui::MainWindow *ui;
    Trem *trem1;
    Trem *trem2;
    Trem *trem3;
    Trem *trem4;
    Semaforo *sem1;
    Semaforo *sem2;
    Semaforo *sem3;
    std::thread infoSem;
    std::thread t;

    //bool first;
};

#endif // MAINWINDOW_H
