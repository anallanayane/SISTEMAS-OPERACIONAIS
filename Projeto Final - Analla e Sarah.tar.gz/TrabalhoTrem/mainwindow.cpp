#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    trem1 = new Trem(1,170,20);
    trem2 = new Trem(2,250,220);
    trem3 = new Trem(3,400,120);
    trem4 = new Trem(4,380,320);

    sem1 = new Semaforo(1,1,IPC_CREAT|0600);
    sem2 = new Semaforo(2,1,IPC_CREAT|0600);
    sem3 = new Semaforo(3,1,IPC_CREAT|0600);

    trem1->sem1 = sem1;
    trem1->sem2 = sem2;
    trem1->sem3 = sem3;

    trem2->sem1 = sem1;
    trem2->sem2 = sem2;
    trem2->sem3 = sem3;

    trem3->sem1 = sem1;
    trem3->sem2 = sem2;
    trem3->sem3 = sem3;

    trem4->sem1 = sem1;
    trem4->sem2 = sem2;
    trem4->sem3 = sem3;



    connect(trem1,SIGNAL(updateGUI(int,int,int,bool)),SLOT(updateInterface(int,int,int,bool)));
    connect(trem2,SIGNAL(updateGUI(int,int,int,bool)),SLOT(updateInterface(int,int,int,bool)));
    connect(trem3,SIGNAL(updateGUI(int,int,int,bool)),SLOT(updateInterface(int,int,int,bool)));
    connect(trem4,SIGNAL(updateGUI(int,int,int,bool)),SLOT(updateInterface(int,int,int,bool)));

    trem1->start();
    trem2->start();
    trem3->start();
    trem4->start();

    t = std::thread(&MainWindow::server, this);  //server

}

MainWindow::~MainWindow()
{
    t.join();
    delete ui;
}

Mensagem::Mensagem()
{
    acao = 20;
}

void MainWindow::socketHandler(MainWindow *window, int socketDescriptor, Mensagem mensagem) {
    int byteslidos;

    //Verificando erros
    if (socketDescriptor == -1) {
        printf("Falha ao executar accept()");
        exit(EXIT_FAILURE);
    }

    // Receber uma msg do cliente
    byteslidos = recv(socketDescriptor, &mensagem, sizeof(mensagem), 0);

    if (byteslidos == -1) {
        printf("Falha ao executar recv()");
        exit(EXIT_FAILURE);
    } else if (byteslidos == 0) {
        printf("Cliente finalizou a conexão\n");
        exit(EXIT_SUCCESS);
    }

    ::close(socketDescriptor);
}

void MainWindow::server() {
    struct sockaddr_in endereco;
    int socketId;

    // variáveis relacionadas com as conexões clientes
    struct sockaddr_in enderecoCliente;
    socklen_t tamanhoEnderecoCliente = sizeof(struct sockaddr);
    int conexaoClienteId;

    //mensagem enviada pelo cliente
    Mensagem mensagem;

    /*
    * Configuracao do endereço
    */

    memset(&endereco, 0, sizeof(endereco));
    endereco.sin_family = AF_INET;
    endereco.sin_port = htons(PORTNUM);
    // endereco.sin_addr.s_addr = INADDR_ANY;
    endereco.sin_addr.s_addr = inet_addr("192.168.7.1");  // PUT YOUR IP HERE "ip addr show" no terminal

    /*
     * Criando o Socket
     *
     * PARAM1: AF_INET ou AF_INET6 (IPV4 ou IPV6)
     * PARAM2: SOCK_STREAM ou SOCK_DGRAM
     * PARAM3: protocolo (IP, UDP, TCP, etc). Valor 0 escolhe automaticamente
     */
    socketId = socket(AF_INET, SOCK_STREAM, 0);

    // Verificar erros
    if (socketId == -1) {
        printf("Falha ao executar socket()\n");
        exit(EXIT_FAILURE);
    }

    // Conectando o socket a uma porta. Executado apenas no lado servidor
    if (bind(socketId, (struct sockaddr *) &endereco, sizeof(struct sockaddr)) == -1) {
        printf("Falha ao executar bind()\n");
        exit(EXIT_FAILURE);
    }

    // Habilitando o servidor a receber conexoes do cliente
    if (listen(socketId, 10) == -1) {
        printf("Falha ao executar listen()\n");
        exit(EXIT_FAILURE);
    }

    while (true) {
        // Servidor fica bloqueado esperando uma conexão do cliente
        conexaoClienteId = accept(socketId, (struct sockaddr *) &enderecoCliente, &tamanhoEnderecoCliente);

        //disparar a thread
        std::thread t(&MainWindow::socketHandler, this, conexaoClienteId, mensagem);
        t.detach();
        //std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}


void MainWindow::infoSemaforo(){
    ui->cont1->display(sem1->getContador());
    ui->cont2->display(sem2->getContador());
    ui->cont3->display(sem3->getContador());
}


void MainWindow::changeVelocidade(int id, int velocidade){
   if(id == 1){
       trem1->setVelocidade(velocidade);
   }
  else if(id == 2){
       trem2->setVelocidade(velocidade);
   }
}

void MainWindow::updateInterface(int id, int x, int y, bool a)
{
    switch(id){
        case 1:
            infoSemaforo();
            ui->labelTrem1->setGeometry(x,y,20,20);
            break;
        case 2:
            infoSemaforo();
            ui->labelTrem2->setGeometry(x,y,20,20);
            break;
       case 3:
            infoSemaforo();
            ui->labelTrem3->setGeometry(x,y,20,20);
            break;
        case 4:
            infoSemaforo();
            ui->labelTrem4->setGeometry(x,y,20,20);
            break;

        default:
            break;
    }
}

void MainWindow::closeEvent(){
    t.detach();
    delete sem1;
    delete sem2;
    delete sem3;
}





