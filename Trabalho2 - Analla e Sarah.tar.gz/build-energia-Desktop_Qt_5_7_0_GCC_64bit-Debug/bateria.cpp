#include "Bateria.h"
#include <string>

using namespace std;

Bateria::Bateria()
{
}

int Bateria::getCarga(){
    return this->carga;
}

double Bateria::getDescarga(){
    return this->descarga;
}

int extrairNumeros(string str){
    int chars = 0;      //variável onde ficam armazenados os dígitos extraídos
    int i;

    for(i=0; str[i]!='\0'; i++){    //percorrer todos os caracteres
        if(isdigit(str[i])){        //verificar se o carácter é numérico
            chars += (long int)(str[i])-'0';    //forma "artesanal" de converter o carácter para inteiro
            chars *= 10;
        }
    }
    
    chars /= 10;    //divide por 10;

    return chars;
}

int lerBateria(){

    int contLinhas = 0;        //contador de linhas do arquivo;
    string currentNow;         //variavel para armazenar a carga atual
    string cargaFull;          //variavel para armazenar a carga completa;
    string cargaNow;           //variavel para armazenar a carga de agora;
    long int descarga;         
    
    //arquivo para salvar os dados da bateria
    system ("cat /sys/class/power_supply/BAT0/uevent > bateria.txt");

    ifstream bateriaFile ("bateria.txt");
    string bateriaInfo;

   // bateriaFile.open("home/anallanayane/bateria.txt");

    //abrindo e lendo o arquivo
    if (bateriaFile.is_open()){
        while (! bateriaFile.eof()){
            ++contLinhas;
            getline(bateriaFile, bateriaInfo);    //atribui as informações do arquivo em bateriaInfo;
            //cout << bateriaInfo;
            if(contLinhas == 7){                 //se estiver na linha de current now, atribui os dados na variavel
                getline(bateriaFile, currentNow);
                cout << currentNow <<endl;
            }
            if (contLinhas == 8){               //se estiver na linha de charge full atribui os dados na variavel
                getline(bateriaFile, cargaFull);
                cout << cargaFull <<endl;
            }
            if (contLinhas == 8){               //se estiver na linha de charge now, atribui os dados na variavel
                getline (bateriaFile, cargaNow);
                cout << cargaNow <<endl;
            }

        }
            //extraindo os numeros das linhas desejadas
            long int crN = extrairNumeros(currentNow);  
            cout << crN <<endl;

            long int cF = extrairNumeros(cargaFull);
            cout << cF <<endl;

            long int cN = extrairNumeros(cargaNow);
            cout << cN <<endl;

            //calculando o tempo de descarga
            descarga = (cF - cN) / crN;
            descarga *= 60;
            cout << descarga <<endl;
            
            bateriaFile.close();    //fechar o arquivo
    }
    
    else{
        cout << "Erro ao abrir o arquivo!";
    }

    return 0;
}
