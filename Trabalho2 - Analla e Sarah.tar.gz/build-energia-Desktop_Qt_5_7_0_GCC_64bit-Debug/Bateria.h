#ifndef BATERIA_H
#define BATERIA_H

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>

class Bateria
{
public:
    Bateria();
    int getCarga();
    double getDescarga();
    int extrairNumeros();
    int lerBateria();
private:
    int carga;
    double descarga;
};

#endif // BATTERY_H
